var webrtcConfig = {
	url: "",
	options: "rtptransport=tcp&timeout=60",
	layoutextraoptions: "&width=320&height=0",
	defaultvideostream: "Bunny"
}
