var xmppRoomConfig = {
	url: "meet.jit.si",
	roomId: "testroom"
}
